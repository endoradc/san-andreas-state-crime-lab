# San Andreas State Crime Laboratory

Fictional GTA roleplay evidence portal. Static HTML, CSS and JavaScript; no dependencies or build step.

## Upload to GitHub
1. Create a repository named `san-andreas-state-crime-lab`.
2. Extract the ZIP on your computer.
3. Upload `dist`, `vercel.json`, and this `README.md` to the repository root. Upload the folder contents, not the ZIP itself.
4. Commit the upload.

## Deploy with Vercel
Import the GitHub repository into Vercel. Use Framework Preset **Other**, keep Root Directory at the repository root, use **dist** as Output Directory, and leave Build and Install Commands empty. The included vercel.json contains these settings.

## Edit reports
- dist/reports.js: harbor and device examination text
- dist/surveillance.js: independent port-camera report and retained stills
- dist/review.js: evidence gallery and stolen shipment manifest
- dist/app.js: case directory and Luis Ortega profile
- dist/cyber.js: Cybercrime Division presentation and page boot
- dist/board.js: evidence link board (people, exhibits and how they connect, with a status on every line)
- dist/jtf-data.js: the restricted Joint Task Force file for Captain Bradford, and its sign-in. Edit this to add information
- dist/jtf.js: sign-in screen and file display
- dist/style.css: styling
- dist/evidence: supplied evidence images

The third camera has no supplied finding; it is explicitly unresolved. No timestamps, plate transcription or occupant identity were invented. Device fingerprint examination records no fingerprints found.

This is a roleplay site, not a real government service. It contains no login system; a public deployment makes its fictional reports accessible to anyone with access to the site.


## Captain Bradford's JTF file
Open **Restricted · JTF file** in the menu. Default sign-in is badge `JTF-0417`, passcode `blood-debt`. Change both at the top of `dist/jtf-data.js`.

To add information, edit `dist/jtf-data.js`. Each section holds entries. Change an entry's `status` from `'pending'` to `'reported'`, `'confirmed'` or `'open'` and fill in its `text`. Wrap words in `[[double brackets]]` to show a black redaction bar. Add a new `{ title, status, text }` line to add an entry.

This sign-in is roleplay gating, not real security. The page runs in the visitor's browser, so anyone who views the page source can read `jtf-data.js` and the passcode. Do not put anything there that must stay private.

## Updating recovery status
In `dist/review.js`, the shipment register lists each firearm. When one is recovered in the story, set its `match` to `true` and change its `status`. The home page tracker counts update automatically.

## Link board
In `dist/board.js`, `boardNodes` are the cards and `boardLinks` are the lines. Each line has a status of `confirmed`, `reported` or `unresolved`. Move a line to `confirmed` when a new finding supports it.
